// File: MachineService.java
package net.javaguides.springboot.service;

import java.util.List;
import net.javaguides.springboot.model.Machine;

public interface MachineService {
    List<Machine> getAllMachines();
    Machine assignTechnicianToMachine(Long machineId, String employeeId);
    List<Machine> getMachinesByLocation(String location);
    Machine saveMachine(Machine machine);
    Machine getMachineById(long id);
    void deleteMachineById(long id);
    Machine getMachineByMachineId(String machineId); // ✅ Added
}
