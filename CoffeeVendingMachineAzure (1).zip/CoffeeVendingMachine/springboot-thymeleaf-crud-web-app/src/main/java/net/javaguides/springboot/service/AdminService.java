// File: AdminService.java
package net.javaguides.springboot.service;

import net.javaguides.springboot.model.Admin;

import java.util.Optional;

public interface AdminService {
    Admin register(Admin admin);
    Optional<Admin> findByEmployeeId(String employeeId);
}
