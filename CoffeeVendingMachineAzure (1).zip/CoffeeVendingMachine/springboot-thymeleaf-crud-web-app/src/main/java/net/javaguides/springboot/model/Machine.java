package net.javaguides.springboot.model;

import javax.persistence.*;

@Entity
public class Machine {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "machine_id", unique = true, nullable = false)
    private String machineId;

    private String location;
    private int temperature;
    private int waterLevel;
    private int coffeeLevel;
    private int milkLevel;
    private int sugarLevel;
    private int floorNumber;
    private String status;

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getMachineId() { return machineId; }
    public void setMachineId(String machineId) { this.machineId = machineId; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public int getTemperature() { return temperature; }
    public void setTemperature(int temperature) { this.temperature = temperature; }

    public int getWaterLevel() { return waterLevel; }
    public void setWaterLevel(int waterLevel) { this.waterLevel = waterLevel; }

    public int getCoffeeLevel() { return coffeeLevel; }
    public void setCoffeeLevel(int coffeeLevel) { this.coffeeLevel = coffeeLevel; }

    public int getMilkLevel() { return milkLevel; }
    public void setMilkLevel(int milkLevel) { this.milkLevel = milkLevel; }

    public int getSugarLevel() { return sugarLevel; }
    public void setSugarLevel(int sugarLevel) { this.sugarLevel = sugarLevel; }

    public int getFloorNumber() { return floorNumber; }
    public void setFloorNumber(int floorNumber) { this.floorNumber = floorNumber; }

    public String getStatus() { return status; }
    public void setStatus(String status) {
        if (status.equals("Working") || status.equals("Under Maintenance")) {
            this.status = status;
        } else {
            throw new IllegalArgumentException("Invalid status");
        }
    }
}
