package net.javaguides.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.javaguides.springboot.model.Users;

import java.util.*;

public interface UsersRepository extends JpaRepository<Users, Long> {

    Users findByEmployeeId(String employeeId);

    List<Users> findByRoleAndLocationIgnoreCase(String role, String location);

    List<Users> findByMachineId(String machineId);

}

