package net.javaguides.springboot.controller;

import net.javaguides.springboot.model.Machine;
import net.javaguides.springboot.service.MachineService;
import net.javaguides.springboot.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/machines")
public class MachineRestController {

    @Autowired
    private MachineService machineService;

    @Autowired
    private NotificationService notificationService;

    @GetMapping
    public List<Machine> getAllMachines() {
        return machineService.getAllMachines();
    }

    @GetMapping("/by-location")
    public List<Machine> getMachinesByLocation(@RequestParam String location) {
        return machineService.getMachinesByLocation(location);
    }

    @GetMapping("/by-machine-id/{machineId}")
    public ResponseEntity<Machine> getMachineByMachineId(@PathVariable String machineId) {
        Machine machine = machineService.getMachineByMachineId(machineId);
        if (machine == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(machine);
    }

    @PostMapping
    public ResponseEntity<Machine> saveMachine(@RequestBody Machine machine) {
        Machine savedMachine = machineService.saveMachine(machine);
        return ResponseEntity.ok(savedMachine);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Machine> updateMachine(@PathVariable Long id, @RequestBody Machine updatedMachine) {
        Machine machine = machineService.getMachineById(id);
        if (machine == null) {
            return ResponseEntity.notFound().build();
        }

        machine.setTemperature(updatedMachine.getTemperature());
        machine.setWaterLevel(updatedMachine.getWaterLevel());
        machine.setCoffeeLevel(updatedMachine.getCoffeeLevel());
        machine.setMilkLevel(updatedMachine.getMilkLevel());
        machine.setSugarLevel(updatedMachine.getSugarLevel());
        machine.setStatus(updatedMachine.getStatus());
        machine.setFloorNumber(updatedMachine.getFloorNumber());

        Machine saved = machineService.saveMachine(machine);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/by-machine-id/{machineId}")
    public ResponseEntity<Machine> updateMachineByMachineId(@PathVariable String machineId, @RequestBody Machine updatedMachine) {
        Machine machine = machineService.getMachineByMachineId(machineId);
        if (machine == null) {
            return ResponseEntity.notFound().build();
        }

        machine.setTemperature(updatedMachine.getTemperature());
        machine.setWaterLevel(updatedMachine.getWaterLevel());
        machine.setCoffeeLevel(updatedMachine.getCoffeeLevel());
        machine.setMilkLevel(updatedMachine.getMilkLevel());
        machine.setSugarLevel(updatedMachine.getSugarLevel());
        machine.setStatus(updatedMachine.getStatus());
        machine.setFloorNumber(updatedMachine.getFloorNumber());

        Machine saved = machineService.saveMachine(machine);

        if (machine.getWaterLevel() < 20 || machine.getMilkLevel() < 10 || machine.getSugarLevel() < 5) {
            notificationService.createNotification("Low resource alert for machine: " + machine.getMachineId(), machine.getMachineId());
}

        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{machineId}/assign-technician/{employeeId}")
    public ResponseEntity<?> assignTechnicianToMachine(@PathVariable Long machineId, @PathVariable String employeeId) {
        Machine updated = machineService.assignTechnicianToMachine(machineId, employeeId);
        if (updated == null) {
            return ResponseEntity.badRequest().body("Invalid machine or technician ID");
        }
        return ResponseEntity.ok(updated);
    }
}
