// File: AdminRepository.java
package net.javaguides.springboot.repository;

import net.javaguides.springboot.model.Admin;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;

public interface AdminRepository extends JpaRepository<Admin, Long> {
    Optional<Admin> findByEmployeeId(String employeeId);
    List<Admin> findByMachineId(String machineId);
}
