package net.javaguides.springboot.service;

import net.javaguides.springboot.model.TelemetryMessage;

import org.springframework.stereotype.Service;

@Service
public class TelemetryService {

    public void processTelemetry(TelemetryMessage data) {
        // Business logic here
        System.out.println("Machine ID: " + data.getMachineId());
        System.out.println("Temperature: " + data.getTemperature());
        System.out.println("Status: " + data.getStatus());

        // You could save this to a DB or call other services
    }
}

