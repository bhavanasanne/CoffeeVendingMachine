package net.javaguides.springboot.service;

import com.azure.messaging.servicebus.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.javaguides.springboot.model.Machine;
import net.javaguides.springboot.service.MachineService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

@Service
public class ServiceBusListener {

    @Value("${azure.servicebus.connection-string}")
    private String connectionString;

    @Value("${azure.servicebus.topic-name}")
    private String topicName;

    @Value("${azure.servicebus.subscription-name}")
    private String subscriptionName;

    private final MachineService machineService;
    private final ObjectMapper objectMapper = new ObjectMapper();
    private ServiceBusProcessorClient processorClient;

    public ServiceBusListener(MachineService machineService) {
        this.machineService = machineService;
    }

    @PostConstruct
    public void start() {
        processorClient = new ServiceBusClientBuilder()
                .connectionString(connectionString)
                .processor()
                .topicName(topicName)
                .subscriptionName(subscriptionName)
                .processMessage(this::processMessage)
                .processError(this::processError)
                .buildProcessorClient();

        processorClient.start();
        System.out.println("Azure Service Bus listener started.");
    }

    private void processMessage(ServiceBusReceivedMessageContext context) {
        try {
            String body = context.getMessage().getBody().toString();
            System.out.println("Received message: " + body);

            Machine machine = objectMapper.readValue(body, Machine.class);
            machineService.saveMachine(machine);
            System.out.println("Machine data saved successfully.");
        } catch (Exception e) {
            System.err.println("Error processing message: " + e.getMessage());
        }
    }

    private void processError(ServiceBusErrorContext context) {
        System.err.println("Error occurred while processing message: " + context.getException());
    }

    @PreDestroy
    public void stop() {
        if (processorClient != null) {
            processorClient.close();
            System.out.println("Azure Service Bus listener stopped.");
        }
    }
}