package net.javaguides.springboot.model;

import javax.persistence.*;

@Entity

public class Users {

    @Id

    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Long id;

    private String employeeId;

    private String password;

    private String role;

    private String location;

    @Column(name = "machine_id")

    private String machineId;

    // ✅ Default constructor (required for JPA and JSON deserialization)

    public Users() {

    }

    // Getters and Setters

    public Long getId() { return id; }

    public void setId(Long id) { this.id = id; }

    public String getEmployeeId() { return employeeId; }

    public void setEmployeeId(String employeeId) { this.employeeId = employeeId; }

    public String getPassword() { return password; }

    public void setPassword(String password) { this.password = password; }

    public String getRole() { return role; }

    public void setRole(String role) { this.role = role; }

    public String getLocation() { return location; }

    public void setLocation(String location) { this.location = location; }

    public String getMachineId() { return machineId; }

    public void setMachineId(String machineId) { this.machineId = machineId; }

}

