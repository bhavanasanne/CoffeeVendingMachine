package net.javaguides.springboot.service;

import net.javaguides.springboot.model.Notification;
import net.javaguides.springboot.repository.NotificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class NotificationServiceImpl implements NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    @Override
    public void createNotification(String message, String machineId) {
        Notification notification = new Notification();
        notification.setMessage(message);
        notification.setTimestamp(LocalDateTime.now());
        notification.setRead(false);
        notification.setMachineId(machineId);

        // ✅ Log to confirm notification creation
        System.out.println("🔔 Notification created: " + message + " for machine " + machineId);

        notificationRepository.save(notification);
    }

    @Override
    public List<Notification> getRecentNotifications() {
        return notificationRepository.findTop10ByOrderByTimestampDesc();
    }

    @Override
    public List<Notification> getNotificationsByMachineId(String machineId) {
        return notificationRepository.findByMachineIdOrderByTimestampDesc(machineId);
    }
}
