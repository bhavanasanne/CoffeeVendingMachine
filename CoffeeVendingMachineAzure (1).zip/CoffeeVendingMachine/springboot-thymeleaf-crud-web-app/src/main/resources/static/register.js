document.addEventListener('DOMContentLoaded', function () {

document.getElementById('backBtn').addEventListener('click', function () {

  window.location.href = '/index';

});


  const employeeIdInput = document.getElementById('employeeId');

  const passwordInput = document.getElementById('password');

  const employeeIdHint = document.getElementById('employeeIdHint');

  const passwordHint = document.getElementById('passwordHint');

  // Real-time validation for Employee ID

  employeeIdInput.addEventListener('input', function () {

    const value = employeeIdInput.value.trim();

    if (!/^\d{7}$/.test(value)) {

      employeeIdHint.textContent = 'Employee ID must be exactly 7 digits.';

      employeeIdHint.style.color = 'red';

    } else {

      employeeIdHint.textContent = 'Valid Employee ID.';

      employeeIdHint.style.color = 'green';

    }

  });

  // Real-time validation for Password

  passwordInput.addEventListener('input', function () {

    const value = passwordInput.value.trim();

    if (!/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&]).{8,}$/.test(value)) {

      passwordHint.textContent = 'Password must be 8+ characters with letters, numbers, and special characters.';

      passwordHint.style.color = 'red';

    } else {

      passwordHint.textContent = 'Strong password.';

      passwordHint.style.color = 'green';

    }

  });

  // Register button logic

  document.getElementById('registerBtn').addEventListener('click', function (e) {

    e.preventDefault();

    const employeeId = employeeIdInput.value.trim();

    const password = passwordInput.value.trim();

    const confirmPassword = document.getElementById('confirmPassword').value.trim();

    const role = document.getElementById('role').value;

    const location = document.getElementById('location').value;

    const rememberMe = document.getElementById('rememberMe').checked;

    // Validation

    if (!/^\d{7}$/.test(employeeId)) {

      showMessage('Employee ID must be exactly 7 digits and numeric', true);

      return;

    }

    if (!/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&]).{8,}$/.test(password)) {

      showMessage('Password must be at least 8 characters and include letters, numbers, and special characters', true);

      return;

    }

    if (password !== confirmPassword) {

      showMessage('Passwords do not match!', true);

      return;

    }

    if (!location) {

      showMessage('Please select a location.', true);

      return;

    }

    // Send registration data

    fetch('http://localhost:8080/api/users/register', {

      method: 'POST',

      headers: { 'Content-Type': 'application/json' },

      body: JSON.stringify({ employeeId, password, role, location })

    })

      .then(response => {

        if (!response.ok) throw new Error('Registration failed');

        return response.json();

      })

      .then(() => {

        if (rememberMe) {

          localStorage.setItem('rememberUser', employeeId);

        }

        showMessage(`Registration successful as ${role} at ${location}!`);

        document.getElementById('registerForm').reset();

        employeeIdHint.textContent = '';

        passwordHint.textContent = '';

      })

      .catch(error => showMessage(error.message, true));

  });

  function showMessage(msg, isError = false) {

    const el = document.getElementById('message');

    el.textContent = msg;

    el.style.color = isError ? 'red' : 'lightgreen';

  }

});

