document.addEventListener("DOMContentLoaded", () => {
    const urlParams = new URLSearchParams(window.location.search);
    const location = urlParams.get("location");

    if (!location) {
        alert("❗ Location parameter is missing in the URL.");
        return;
    }

    console.log("📍 Location from URL:", location);

    // Set the title
    const titleElement = document.getElementById("locationTitle");
    if (titleElement) {
        titleElement.textContent = `Machines at ${location}`;
    }

    // Fetch and render machines
    fetch(`/api/machines/by-location?location=${encodeURIComponent(location)}`)
        .then(res => {
            if (!res.ok) throw new Error("Network response was not ok");
            return res.json();
        })
        .then(machines => {
            renderMachines(machines);
        })
        .catch(err => {
            alert("❌ Failed to load machines.");
            console.error("Error loading machines:", err);
        });

    // Notification button logic
    const notifyBtn = document.getElementById("notificationBtn");
    if (notifyBtn) {
        notifyBtn.addEventListener("click", () => {
            console.log("🔔 Checking alerts for location:", location);

            fetch(`/api/notifications/alerts?location=${encodeURIComponent(location)}`)
                .then(res => {
                    if (!res.ok) throw new Error("Network response was not ok");
                    return res.json();
                })
                .then(alerts => {
                    console.log("📬 Alerts received:", alerts);
                    if (alerts.length > 0) {
                        alert("⚠️ Alert! The following machines need attention:\n" + alerts.join("\n"));
                    } else {
                        alert("✅ All machines are operating within safe parameters.");
                    }
                })
                .catch(err => {
                    alert("❌ Failed to fetch alerts.");
                    console.error("Error fetching alerts:", err);
                });
        });
    }
});

function renderMachines(machines) {

    const container = document.getElementById("machineList");

    if (!container) return;

    container.innerHTML = "";

    if (!machines || machines.length === 0) {

        container.innerHTML = "<p style='color:white;'>No machines found for this location.</p>";

        return;

    }

    machines.forEach(machine => {

        const tempCelsius = (machine.temperature - 273.15).toFixed(2); // Convert Kelvin to Celsius

        const div = document.createElement("div");

        div.className = "machine-card";

        div.innerHTML = `
<h4>${machine.machineId}</h4>
<p>Temperature: ${tempCelsius}°C</p>
<p>Water Level: ${machine.waterLevel}%</p>
<p>Coffee Level: ${machine.coffeeLevel}%</p>
<p>Milk Level: ${machine.milkLevel}%</p>
<p>Sugar Level: ${machine.sugarLevel}%</p>
<p>Status: ${machine.status}</p>
<p>Floor: ${machine.floorNumber}</p>

        `;

        container.appendChild(div);

    });

}
